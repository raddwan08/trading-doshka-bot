# Trading Doshka Bot — GitHub + Railway

بوت Telegram لتحليل العملات مع اشتراكات USDT متعددة الشبكات:

- Solana
- Ethereum
- BSC

## 1) Railway Variables

أضف هذه المتغيرات في Railway:

```text
BOT_TOKEN=توكن البوت
ADMIN_ID=رقم تيليجرام للمدير

SOL_WALLET=عنوان محفظة Solana
ETH_WALLET=عنوان محفظة Ethereum
BSC_WALLET=عنوان محفظة BSC

SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
ETH_RPC_URL=https://ethereum-rpc.publicnode.com
BSC_RPC_URL=https://bsc-rpc.publicnode.com

ETH_USDT_CONTRACT=0xdAC17F958D2ee523a2206206994597C13D831ec7
BSC_USDT_CONTRACT=0x55d398326f99059fF775485246999027B3197955
SOL_USDT_MINT=Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB
```

استخدم القيمة الصحيحة لـ `SOL_USDT_MINT` كما هي في `.env.example`:

```text
Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB
```

لا تضع `BOT_TOKEN` داخل GitHub.

## 2) الدفع

النظام لا يحول الأموال بنفسه. المستخدم يرسل USDT مباشرة إلى عنوان المحفظة الموجود في متغير الشبكة.

بعد ذلك يقرأ البوت البلوكشين ويتحقق من:
- الشبكة
- عقد/Token USDT الصحيح
- عنوان الاستلام
- المبلغ المطلوب
- تأكيدات المعاملة
- عدم استخدام TX سابق لتفعيل اشتراك آخر

## 3) GitHub

ارفع الملفات:

- `bot.py`
- `requirements.txt`
- `Dockerfile`
- `Procfile`
- `railway.json`
- `.gitignore`
- `.dockerignore`
- `.env.example`
- `README.md`

ولا ترفع:
- `.env`
- قاعدة البيانات
- BOT_TOKEN

## 4) Railway

اربط المستودع بخدمة Worker.

Railway سيكتشف `Dockerfile` ويشغل:

```text
python bot.py
```

## 5) ملاحظة مهمة

SQLite داخل Railway مناسبة للاختبار/الاستخدام الخفيف، لكن للإنتاج عالي الاعتمادية يفضل ربط PostgreSQL دائم. الكود الحالي يستخدم SQLite مع WAL ويضمن عدم تكرار TX داخل نفس الخدمة.

## 6) فحص الدفع

اضغط المستخدم:
`الاشتراك -> الباقة -> الشبكة`

ثم يحول USDT إلى عنوان الشبكة.

بعد وصول المعاملة:
`فحص الآن`

لا يحتاج المستخدم لإرسال TX Hash.

## 7) اختبار قبل الإنتاج

ابدأ بتحويل صغير على كل شبكة وتأكد أن:
1. المعاملة وصلت للعنوان الصحيح.
2. البوت لا يفعّل الاشتراك قبل التأكيد.
3. الضغط المتكرر على «فحص الآن» لا يكرر التفعيل.
4. التحويل على شبكة مختلفة لا يتم قبوله.
