import asyncio
import io
import logging
import math
import os
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp
import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder


# ----------------------------
# Configuration
# ----------------------------

def env_int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except ValueError:
        return default


BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = env_int("ADMIN_ID", env_int("ADMIN_USER_ID", 0))

SQLITE_PATH = os.getenv("SQLITE_PATH", "data/subscriptions.db").strip()

# These are intentionally read from Railway/GitHub environment variables.
# Do not put private keys/secrets in GitHub.
SOL_WALLET = os.getenv("SOL_WALLET", "").strip()
ETH_WALLET = os.getenv("ETH_WALLET", "").strip().lower()
BSC_WALLET = os.getenv("BSC_WALLET", "").strip().lower()

SOLANA_RPC_URL = os.getenv(
    "SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com"
).strip()
ETH_RPC_URL = os.getenv(
    "ETH_RPC_URL", "https://ethereum-rpc.publicnode.com"
).strip()
BSC_RPC_URL = os.getenv(
    "BSC_RPC_URL", "https://bsc-rpc.publicnode.com"
).strip()

ETH_USDT_CONTRACT = os.getenv(
    "ETH_USDT_CONTRACT",
    "0xdAC17F958D2ee523a2206206994597C13D831ec7",
).strip().lower()

BSC_USDT_CONTRACT = os.getenv(
    "BSC_USDT_CONTRACT",
    "0x55d398326f99059fF775485246999027B3197955",
).strip().lower()

# Official Solana mainnet USDT mint.
SOL_USDT_MINT = os.getenv(
    "SOL_USDT_MINT",
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
).strip()

PAYMENT_SCAN_SECONDS = max(10, env_int("PAYMENT_SCAN_SECONDS", 30))
MIN_CONFIRMATIONS = max(0, env_int("MIN_CONFIRMATIONS", 1))
EVM_SCAN_BLOCKS = max(500, env_int("EVM_SCAN_BLOCKS", 8000))
SOLANA_SIGNATURE_LIMIT = max(20, min(100, env_int("SOLANA_SIGNATURE_LIMIT", 100)))

if not BOT_TOKEN:
    raise SystemExit("BOT_TOKEN is required")

if not ADMIN_ID:
    logging.warning("ADMIN_ID is not configured. Admin-only features are disabled.")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("trading-doshka")

PLANS = {
    "1m": {"days": 30, "price": 20.0, "name": "شهر", "emoji": "📅"},
    "3m": {"days": 90, "price": 50.0, "name": "3 أشهر", "emoji": "💎"},
    "6m": {"days": 180, "price": 75.0, "name": "6 أشهر", "emoji": "👑"},
    "1y": {"days": 365, "price": 125.0, "name": "سنة", "emoji": "🏆"},
}

NETWORKS = {
    "sol": {"name": "Solana", "wallet": SOL_WALLET},
    "eth": {"name": "Ethereum", "wallet": ETH_WALLET},
    "bnb": {"name": "BSC", "wallet": BSC_WALLET},
}

COINS = ["BTC", "ETH", "SOL", "BNB", "XRP", "ADA", "DOGE", "AVAX"]

SCHOOLS = {
    "wyckoff": {"name": "وايكوف", "emoji": "📊", "timeframes": ["1h", "4h", "1d"]},
    "elliott": {"name": "إليوت", "emoji": "🌊", "timeframes": ["1h", "4h", "1d"]},
    "harmonic": {"name": "هارمونيك", "emoji": "🦋", "timeframes": ["1h", "4h", "1d"]},
    "classic": {"name": "كلاسيكي", "emoji": "📈", "timeframes": ["15m", "1h", "4h", "1d"]},
    "whales": {"name": "الحيتان", "emoji": "🐋", "timeframes": ["1h", "4h", "1d"]},
    "tvl": {"name": "السيولة", "emoji": "💧", "timeframes": ["1d"]},
}

VALID_TF = {"15m", "1h", "4h", "1d"}

# keccak256("Transfer(address,address,uint256)")
TRANSFER_TOPIC = (
    "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
)


class States(StatesGroup):
    custom = State()


# ----------------------------
# Helpers
# ----------------------------

def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        d = datetime.fromisoformat(value)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def normalize_symbol(value: str) -> str:
    s = re.sub(r"[^A-Za-z0-9]", "", value or "").upper()
    return s[:-4] if s.endswith("USDT") else s


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


async def http_json(
    session: aiohttp.ClientSession,
    method: str,
    url: str,
    *,
    json_body: dict | None = None,
    params: dict | None = None,
    timeout: int = 20,
) -> Any:
    try:
        async with session.request(
            method,
            url,
            json=json_body,
            params=params,
            timeout=aiohttp.ClientTimeout(total=timeout),
            headers={"User-Agent": "TradingDoshkaBot/1.0"},
        ) as resp:
            if resp.status != 200:
                text = await resp.text()
                log.warning("HTTP %s %s -> %s: %s", method, url, resp.status, text[:300])
                return None
            return await resp.json(content_type=None)
    except Exception as exc:
        log.warning("HTTP error %s %s: %s", method, url, exc)
        return None


# ----------------------------
# Database
# ----------------------------

class Database:
    def __init__(self, path: str):
        self.path = path
        self.lock = asyncio.Lock()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        return conn

    async def init(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        async with self.lock:
            conn = self.connect()
            conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                PRAGMA foreign_keys=ON;

                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    plan TEXT,
                    start_date TEXT,
                    expire_date TEXT,
                    is_active INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plan TEXT NOT NULL,
                    network TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending'
                );

                CREATE TABLE IF NOT EXISTS used_transactions (
                    tx_id TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    plan TEXT NOT NULL,
                    network TEXT NOT NULL,
                    amount REAL NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_orders_user_status
                    ON orders(user_id, status);

                CREATE INDEX IF NOT EXISTS idx_used_tx_user
                    ON used_transactions(user_id);
                """
            )
            if ADMIN_ID:
                conn.execute(
                    "INSERT OR IGNORE INTO users(user_id, is_active) VALUES(?, 1)",
                    (ADMIN_ID,),
                )
            conn.commit()
            conn.close()

    async def upsert_user(self, user_id: int, username: str | None) -> None:
        async with self.lock:
            conn = self.connect()
            conn.execute(
                """
                INSERT INTO users(user_id, username)
                VALUES(?, ?)
                ON CONFLICT(user_id) DO UPDATE SET username=excluded.username
                """,
                (user_id, username or ""),
            )
            conn.commit()
            conn.close()

    async def is_active(self, user_id: int) -> bool:
        if ADMIN_ID and user_id == ADMIN_ID:
            return True
        async with self.lock:
            conn = self.connect()
            row = conn.execute(
                "SELECT expire_date, is_active FROM users WHERE user_id=?",
                (user_id,),
            ).fetchone()
            conn.close()
        if not row or not row["is_active"]:
            return False
        exp = parse_iso(row["expire_date"])
        return bool(exp and exp > utc_now())

    async def status(self, user_id: int) -> sqlite3.Row | None:
        async with self.lock:
            conn = self.connect()
            row = conn.execute(
                "SELECT plan, start_date, expire_date, is_active "
                "FROM users WHERE user_id=?",
                (user_id,),
            ).fetchone()
            conn.close()
        return row

    async def create_order(self, user_id: int, plan: str, network: str) -> int:
        async with self.lock:
            conn = self.connect()
            conn.execute(
                "UPDATE orders SET status='cancelled' "
                "WHERE user_id=? AND status='pending'",
                (user_id,),
            )
            cur = conn.execute(
                "INSERT INTO orders(user_id, plan, network, created_at) "
                "VALUES(?, ?, ?, ?)",
                (user_id, plan, network, utc_now().isoformat()),
            )
            order_id = int(cur.lastrowid)
            conn.commit()
            conn.close()
        return order_id

    async def pending_order(self, user_id: int) -> sqlite3.Row | None:
        async with self.lock:
            conn = self.connect()
            row = conn.execute(
                """
                SELECT id, user_id, plan, network, created_at
                FROM orders
                WHERE user_id=? AND status='pending'
                ORDER BY id DESC LIMIT 1
                """,
                (user_id,),
            ).fetchone()
            conn.close()
        return row

    async def pending_orders(self) -> list[sqlite3.Row]:
        async with self.lock:
            conn = self.connect()
            rows = conn.execute(
                """
                SELECT id, user_id, plan, network, created_at
                FROM orders
                WHERE status='pending'
                ORDER BY id ASC
                LIMIT 100
                """
            ).fetchall()
            conn.close()
        return rows

    async def claim_transaction(
        self, tx_id: str, user_id: int, plan: str, network: str, amount: float
    ) -> bool:
        async with self.lock:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                if conn.execute(
                    "SELECT 1 FROM used_transactions WHERE tx_id=?",
                    (tx_id,),
                ).fetchone():
                    conn.rollback()
                    return False

                conn.execute(
                    """
                    INSERT INTO used_transactions(
                        tx_id, user_id, plan, network, amount, created_at
                    ) VALUES(?, ?, ?, ?, ?, ?)
                    """,
                    (tx_id, user_id, plan, network, amount, utc_now().isoformat()),
                )
                conn.execute(
                    "UPDATE orders SET status='paid' "
                    "WHERE id=? AND user_id=? AND status='pending'",
                    (self._pending_order_id_sync(conn, user_id), user_id),
                )
                conn.commit()
                return True
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    @staticmethod
    def _pending_order_id_sync(conn: sqlite3.Connection, user_id: int) -> int:
        row = conn.execute(
            "SELECT id FROM orders WHERE user_id=? AND status='pending' "
            "ORDER BY id DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        if not row:
            raise RuntimeError("Pending order disappeared")
        return int(row["id"])

    async def activate(self, user_id: int, plan: str) -> datetime:
        now = utc_now()
        async with self.lock:
            conn = self.connect()
            old = conn.execute(
                "SELECT expire_date, is_active FROM users WHERE user_id=?",
                (user_id,),
            ).fetchone()
            base = now
            if old and old["is_active"]:
                old_exp = parse_iso(old["expire_date"])
                if old_exp and old_exp > base:
                    base = old_exp

            exp = base + timedelta(days=PLANS[plan]["days"])
            conn.execute(
                """
                INSERT INTO users(
                    user_id, plan, start_date, expire_date, is_active
                ) VALUES(?, ?, ?, ?, 1)
                ON CONFLICT(user_id) DO UPDATE SET
                    plan=excluded.plan,
                    start_date=excluded.start_date,
                    expire_date=excluded.expire_date,
                    is_active=1
                """,
                (user_id, plan, now.isoformat(), exp.isoformat()),
            )
            conn.commit()
            conn.close()
        return exp

    async def deactivate_expired(self) -> None:
        async with self.lock:
            conn = self.connect()
            conn.execute(
                """
                UPDATE users SET is_active=0
                WHERE is_active=1 AND expire_date IS NOT NULL
                  AND expire_date <= ?
                """,
                (utc_now().isoformat(),),
            )
            conn.commit()
            conn.close()


db = Database(SQLITE_PATH)


# ----------------------------
# Market data
# ----------------------------

async def get_klines(symbol: str, timeframe: str, limit: int = 220) -> list[dict]:
    symbol = normalize_symbol(symbol)
    if not symbol or timeframe not in VALID_TF:
        return []

    url = "https://api.binance.com/api/v3/klines"
    params = {"symbol": f"{symbol}USDT", "interval": timeframe, "limit": limit}

    async with aiohttp.ClientSession() as session:
        data = await http_json(session, "GET", url, params=params, timeout=15)

    if not isinstance(data, list):
        return []

    candles = []
    for item in data:
        try:
            candles.append(
                {
                    "open": float(item[1]),
                    "high": float(item[2]),
                    "low": float(item[3]),
                    "close": float(item[4]),
                    "volume": float(item[5]),
                    "time": datetime.fromtimestamp(item[0] / 1000, tz=timezone.utc),
                }
            )
        except (IndexError, TypeError, ValueError):
            continue
    return candles


def sma(values: list[float], period: int) -> float:
    if len(values) < period:
        return float(np.mean(values)) if values else 0.0
    return float(np.mean(values[-period:]))


def ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2 / (period + 1)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result


def rsi(values: list[float], period: int = 14) -> float:
    if len(values) <= period:
        return 50.0
    gains = []
    losses = []
    for prev, cur in zip(values[:-1], values[1:]):
        delta = cur - prev
        gains.append(max(delta, 0))
        losses.append(max(-delta, 0))
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def atr(candles: list[dict], period: int = 14) -> float:
    if len(candles) < period + 1:
        return 0.0
    trs = []
    prev_close = candles[0]["close"]
    for c in candles[1:]:
        trs.append(
            max(
                c["high"] - c["low"],
                abs(c["high"] - prev_close),
                abs(c["low"] - prev_close),
            )
        )
        prev_close = c["close"]
    return float(np.mean(trs[-period:]))


def volume_ratio(candles: list[dict], period: int = 20) -> float:
    if len(candles) < period + 1:
        return 1.0
    avg = sma([x["volume"] for x in candles[:-1]], period)
    return candles[-1]["volume"] / avg if avg else 1.0


def support_resistance(candles: list[dict]) -> dict:
    if not candles:
        return {"supports": [], "resistances": []}
    current = candles[-1]["close"]
    highs = [x["high"] for x in candles]
    lows = [x["low"] for x in candles]
    supports, resistances = [], []

    for i in range(2, len(candles) - 2):
        if highs[i] > highs[i - 1] and highs[i] >= highs[i + 1]:
            if highs[i] > current:
                resistances.append(highs[i])
        if lows[i] < lows[i - 1] and lows[i] <= lows[i + 1]:
            if lows[i] < current:
                supports.append(lows[i])

    return {
        "supports": sorted(set(supports), reverse=True)[:3],
        "resistances": sorted(set(resistances))[:3],
    }


def decision_levels(candles: list[dict], action: str) -> tuple[list[float], float, list[float]]:
    current = candles[-1]["close"]
    a = atr(candles) or current * 0.02
    if action == "BUY":
        return [current], current - 1.8 * a, [current + 2.5 * a, current + 4.0 * a]
    if action == "SELL":
        return [current], current + 1.8 * a, [current - 2.5 * a, current - 4.0 * a]
    return [current], current - a, [current + 2 * a]


def confidence(value: float) -> int:
    return max(50, min(95, int(round(value))))


def pack_signal(
    symbol: str,
    school: str,
    action: str,
    conf: int,
    details: str,
    candles: list[dict],
) -> dict:
    entry, stop, targets = decision_levels(candles, action)
    sr = support_resistance(candles)
    action_text = {
        "BUY": "🟢 شراء",
        "SELL": "🔴 بيع",
        "WAIT": "⏳ انتظار",
    }[action]

    text = (
        f"{SCHOOLS[school]['emoji']} <b>{SCHOOLS[school]['name']} — "
        f"{symbol}/USDT</b>\n\n"
        f"{details}\n\n"
        f"التوصية: <b>{action_text}</b>\n"
        f"الثقة: <b>{conf}%</b>\n\n"
        f"💡 الدخول: {', '.join(f'${x:.8g}' for x in entry)}\n"
        f"🛑 الوقف: ${stop:.8g}\n"
        f"🎯 الأهداف: {', '.join(f'${x:.8g}' for x in targets)}\n\n"
        "⚠️ التحليل آلي وليس ضمانًا للربح."
    )
    return {
        "analysis": text,
        "action": action,
        "confidence": conf,
        "entry": entry,
        "stop_loss": stop,
        "take_profit": targets,
        "sr": sr,
    }


# ----------------------------
# Independent analysis schools
# ----------------------------

def classic(c: list[dict], symbol: str) -> dict:
    closes = [x["close"] for x in c]
    e20 = ema(closes, 20)[-1]
    e50 = ema(closes, 50)[-1]
    e200 = ema(closes, 200)[-1]
    r = rsi(closes)
    v = volume_ratio(c)

    score = 0
    score += 1 if closes[-1] > e20 else -1
    score += 1 if e20 > e50 else -1
    score += 1 if e50 > e200 else -1
    score += 1 if r > 52 else -1 if r < 48 else 0
    score += 1 if v > 1.15 and closes[-1] > closes[-2] else 0

    action = "BUY" if score >= 3 else "SELL" if score <= -3 else "WAIT"
    conf = confidence(60 + abs(score) * 7 + min(v, 2) * 3)
    details = (
        f"EMA20: ${e20:.8g}\nEMA50: ${e50:.8g}\nEMA200: ${e200:.8g}\n"
        f"RSI14: {r:.1f}\nنسبة الحجم: {v:.2f}x"
    )
    return pack_signal(symbol, "classic", action, conf, details, c)


def wyckoff(c: list[dict], symbol: str) -> dict:
    closes = [x["close"] for x in c]
    v = volume_ratio(c)
    price_vs_sma = (closes[-1] / sma(closes, 20) - 1) * 100
    range20 = max(x["high"] for x in c[-20:]) - min(x["low"] for x in c[-20:])
    compression = range20 / closes[-1] if closes[-1] else 0

    if v >= 1.6 and price_vs_sma <= -2:
        action = "BUY"
        read = "حجم مرتفع مع ضعف سعري: احتمال امتصاص/تجميع."
    elif v >= 1.6 and price_vs_sma >= 2:
        action = "SELL"
        read = "حجم مرتفع مع امتداد سعري: احتمال توزيع."
    else:
        action = "WAIT"
        read = "لا توجد بصمة حجم/سعر قوية كفاية."

    conf = confidence(58 + min(v, 2.5) * 10 + min(abs(price_vs_sma), 5) * 2)
    details = (
        f"حجم/متوسط20: {v:.2f}x\n"
        f"السعر مقابل SMA20: {price_vs_sma:.2f}%\n"
        f"مدى آخر20: {compression*100:.2f}%\n"
        f"قراءة وايكوف: {read}"
    )
    return pack_signal(symbol, "wyckoff", action, conf, details, c)


def elliott(c: list[dict], symbol: str) -> dict:
    highs = [x["high"] for x in c]
    lows = [x["low"] for x in c]
    pivots = []

    for i in range(2, len(c) - 2):
        if highs[i] > max(highs[i - 2:i]) and highs[i] >= max(highs[i + 1:i + 3]):
            pivots.append(("H", highs[i]))
        elif lows[i] < min(lows[i - 2:i]) and lows[i] <= min(lows[i + 1:i + 3]):
            pivots.append(("L", lows[i]))

    last = pivots[-7:]
    higher_highs = sum(
        last[i][0] == "H" and last[i][1] > last[i - 1][1]
        for i in range(1, len(last))
    )
    higher_lows = sum(
        last[i][0] == "L" and last[i][1] > last[i - 1][1]
        for i in range(1, len(last))
    )
    lower_highs = sum(
        last[i][0] == "H" and last[i][1] < last[i - 1][1]
        for i in range(1, len(last))
    )
    lower_lows = sum(
        last[i][0] == "L" and last[i][1] < last[i - 1][1]
        for i in range(1, len(last))
    )

    score = higher_highs + higher_lows - lower_highs - lower_lows
    action = "BUY" if score >= 2 else "SELL" if score <= -2 else "WAIT"
    conf = confidence(58 + abs(score) * 5)
    details = (
        f"عدد نقاط التحول: {len(last)}\n"
        f"HH/HL: {higher_highs}/{higher_lows}\n"
        f"LH/LL: {lower_highs}/{lower_lows}\n"
        "القراءة تعتمد على بنية القمم والقيعان، وليست ترقيم موجات يدويًا."
    )
    return pack_signal(symbol, "elliott", action, conf, details, c)


def harmonic(c: list[dict], symbol: str) -> dict:
    highs = [x["high"] for x in c]
    lows = [x["low"] for x in c]
    pivots = []

    for i in range(3, len(c) - 3):
        if highs[i] == max(highs[i - 3:i + 4]):
            pivots.append(("H", highs[i]))
        elif lows[i] == min(lows[i - 3:i + 4]):
            pivots.append(("L", lows[i]))

    p = pivots[-5:]
    ratios = []
    if len(p) >= 5:
        vals = [x[1] for x in p]
        xa = abs(vals[1] - vals[0]) or 1
        ab = abs(vals[2] - vals[1])
        bc = abs(vals[3] - vals[2])
        cd = abs(vals[4] - vals[3])
        ratios = [ab / xa, bc / ab if ab else 0, cd / bc if bc else 0]

    # Loose Fibonacci-style proximity rather than pretending to identify a
    # perfect textbook pattern.
    targets = [(0.382, 0.618), (0.618, 0.786), (1.272, 1.618)]
    matches = sum(
        lo <= ratio <= hi for ratio, (lo, hi) in zip(ratios, targets)
    )

    last_type = p[-1][0] if p else None
    action = "BUY" if matches >= 2 and last_type == "L" else (
        "SELL" if matches >= 2 and last_type == "H" else "WAIT"
    )
    conf = confidence(55 + matches * 10)
    ratio_text = ", ".join(f"{x:.2f}" for x in ratios) or "غير كافٍ"
    details = (
        f"نسب AB/XA, BC/AB, CD/BC: {ratio_text}\n"
        f"مطابقة نطاقات فيبوناتشي: {matches}/3\n"
        "هذه قراءة احتمالية للنمط وليست إثباتًا لنموذج هارمونيك مكتمل."
    )
    return pack_signal(symbol, "harmonic", action, conf, details, c)


def whales(c: list[dict], symbol: str) -> dict:
    vols = [x["volume"] for x in c]
    closes = [x["close"] for x in c]
    avg = sma(vols, 30)
    vr = vols[-1] / avg if avg else 1
    candle_body = abs(closes[-1] - c[-1]["open"])
    candle_range = max(c[-1]["high"] - c[-1]["low"], 1e-12)
    body_ratio = candle_body / candle_range
    direction = 1 if closes[-1] > c[-1]["open"] else -1

    if vr > 2.0 and body_ratio > 0.45:
        action = "BUY" if direction > 0 else "SELL"
    else:
        action = "WAIT"

    conf = confidence(58 + min(vr, 3) * 8 + body_ratio * 8)
    details = (
        f"الحجم مقابل متوسط30: {vr:.2f}x\n"
        f"قوة جسم الشمعة: {body_ratio:.2f}\n"
        "الإشارة تبحث عن نشاط حجمي غير اعتيادي، ولا تعني معرفة هوية المتداول."
    )
    return pack_signal(symbol, "whales", action, conf, details, c)


def liquidity(c: list[dict], symbol: str) -> dict:
    closes = [x["close"] for x in c]
    vols = [x["volume"] for x in c]
    price_change = (closes[-1] / closes[-20] - 1) * 100 if len(c) >= 20 else 0
    vol_change = (sma(vols, 5) / sma(vols[:-5], 20) - 1) * 100 if len(c) >= 30 else 0
    r = rsi(closes)

    if price_change > 3 and vol_change > 10 and r < 72:
        action = "BUY"
    elif price_change < -3 and vol_change > 10 and r > 28:
        action = "SELL"
    else:
        action = "WAIT"

    conf = confidence(58 + min(abs(price_change), 8) * 2 + min(abs(vol_change), 30) * 0.3)
    details = (
        f"تغير السعر/20: {price_change:.2f}%\n"
        f"تغير متوسط الحجم: {vol_change:.2f}%\n"
        f"RSI14: {r:.1f}\n"
        "هذه قراءة لتدفق السيولة عبر السعر والحجم، وليست TVL بروتوكولات DeFi."
    )
    return pack_signal(symbol, "tvl", action, conf, details, c)


ANALYZERS = {
    "classic": classic,
    "wyckoff": wyckoff,
    "elliott": elliott,
    "harmonic": harmonic,
    "whales": whales,
    "tvl": liquidity,
}


# ----------------------------
# Chart
# ----------------------------

def render_chart(candles: list[dict], signal: dict, symbol: str, school_name: str) -> io.BytesIO:
    fig, ax = plt.subplots(figsize=(10, 5.5))
    x = list(range(len(candles)))
    closes = [c["close"] for c in candles]
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]
    opens = [c["open"] for c in candles]

    for i, (o, h, l, cl) in enumerate(zip(opens, highs, lows, closes)):
        ax.vlines(i, l, h, linewidth=0.8)
        bottom = min(o, cl)
        height = max(abs(cl - o), (h - l) * 0.002)
        ax.add_patch(
            plt.Rectangle(
                (i - 0.28, bottom),
                0.56,
                height,
                fill=False,
                linewidth=0.8,
            )
        )

    e20 = ema(closes, 20)
    e50 = ema(closes, 50)
    ax.plot(x, e20, linewidth=1.0, label="EMA20")
    ax.plot(x, e50, linewidth=1.0, label="EMA50")

    ax.axhline(signal["stop_loss"], linewidth=1.0, linestyle="--", label="Stop")
    for target in signal["take_profit"]:
        ax.axhline(target, linewidth=1.0, linestyle=":", label="Target")

    ax.set_title(f"{symbol}/USDT — {school_name}")
    ax.grid(alpha=0.15)
    ax.legend(loc="upper left", fontsize=8)
    ax.set_xlim(-1, len(candles))
    fig.tight_layout()

    output = io.BytesIO()
    fig.savefig(output, format="png", dpi=150)
    plt.close(fig)
    output.seek(0)
    return output


# ----------------------------
# Blockchain payment verification
# ----------------------------

def evm_address_topic(address: str) -> str:
    return "0x" + ("0" * 24) + address[2:].lower()


@dataclass
class Payment:
    tx_id: str
    network: str
    amount: float


async def evm_latest_block(session: aiohttp.ClientSession, rpc_url: str) -> int | None:
    body = {"jsonrpc": "2.0", "id": 1, "method": "eth_blockNumber", "params": []}
    data = await http_json(session, "POST", rpc_url, json_body=body, timeout=15)
    try:
        return int(data["result"], 16)
    except (TypeError, KeyError, ValueError):
        return None


async def evm_block_timestamp(
    session: aiohttp.ClientSession, rpc_url: str, block_number_hex: str
) -> int | None:
    body = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "eth_getBlockByNumber",
        "params": [block_number_hex, False],
    }
    data = await http_json(session, "POST", rpc_url, json_body=body, timeout=15)
    try:
        return int(data["result"]["timestamp"], 16)
    except (TypeError, KeyError, ValueError):
        return None


async def verify_evm_payment(
    session: aiohttp.ClientSession,
    rpc_url: str,
    token_contract: str,
    recipient: str,
    expected_amount: float,
    decimals: int,
    created_at: datetime,
) -> Payment | None:
    if not rpc_url or not recipient or not token_contract:
        return None

    latest = await evm_latest_block(session, rpc_url)
    if latest is None:
        return None

    from_block = max(0, latest - EVM_SCAN_BLOCKS)
    # Split the range so public RPCs are less likely to reject the request.
    step = 1500
    recipient_topic = evm_address_topic(recipient)
    required_units = int(round(expected_amount * (10 ** decimals)))

    for start in range(from_block, latest + 1, step):
        end = min(latest, start + step - 1)
        filter_params = {
            "fromBlock": hex(start),
            "toBlock": hex(end),
            "address": token_contract,
            "topics": [TRANSFER_TOPIC, None, recipient_topic],
        }
        body = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_getLogs",
            "params": [filter_params],
        }
        data = await http_json(session, "POST", rpc_url, json_body=body, timeout=20)
        logs = data.get("result") if isinstance(data, dict) else None
        if not isinstance(logs, list):
            continue

        for log_item in reversed(logs):
            try:
                tx_hash = str(log_item["transactionHash"]).lower()
                raw = int(log_item["data"], 16)
                amount = raw / (10 ** decimals)
                if amount + 1e-9 < expected_amount:
                    continue

                # Require enough confirmations.
                block_number = int(log_item["blockNumber"], 16)
                confirmations = latest - block_number + 1
                if confirmations < MIN_CONFIRMATIONS:
                    continue

                block_ts = await evm_block_timestamp(
                    session, rpc_url, log_item["blockNumber"]
                )
                if block_ts is None or block_ts < int(created_at.timestamp()):
                    continue

                return Payment(tx_hash, "evm", amount)
            except (KeyError, TypeError, ValueError):
                continue

    return None


async def solana_rpc(
    session: aiohttp.ClientSession, method: str, params: list
) -> Any:
    body = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return await http_json(
        session, "POST", SOLANA_RPC_URL, json_body=body, timeout=20
    )


async def verify_solana_payment(
    session: aiohttp.ClientSession,
    recipient: str,
    expected_amount: float,
    created_at: datetime,
) -> Payment | None:
    if not recipient:
        return None

    accounts_response = await solana_rpc(
        session,
        "getTokenAccountsByOwner",
        [
            recipient,
            {"mint": SOL_USDT_MINT},
            {"encoding": "jsonParsed"},
        ],
    )
    try:
        accounts = accounts_response["result"]["value"]
    except (TypeError, KeyError):
        return None

    expected_raw = int(round(expected_amount * 1_000_000))

    for account in accounts:
        token_account = account.get("pubkey")
        if not token_account:
            continue

        sig_response = await solana_rpc(
            session,
            "getSignaturesForAddress",
            [
                token_account,
                {"limit": SOLANA_SIGNATURE_LIMIT, "commitment": "finalized"},
            ],
        )
        signatures = (
            sig_response.get("result", []) if isinstance(sig_response, dict) else []
        )

        for sig_info in signatures:
            signature = sig_info.get("signature")
            if not signature or sig_info.get("err") is not None:
                continue

            tx_response = await solana_rpc(
                session,
                "getTransaction",
                [
                    signature,
                    {
                        "encoding": "jsonParsed",
                        "commitment": "finalized",
                        "maxSupportedTransactionVersion": 0,
                    },
                ],
            )
            tx = tx_response.get("result") if isinstance(tx_response, dict) else None
            if not tx:
                continue

            meta = tx.get("meta") or {}
            if meta.get("err") is not None:
                continue

            block_time = tx.get("blockTime")
            if block_time is not None and block_time < int(created_at.timestamp()):
                continue

            pre = {}
            post = {}
            for item in meta.get("preTokenBalances") or []:
                if item.get("mint") == SOL_USDT_MINT:
                    pre[item.get("accountIndex")] = int(
                        item.get("uiTokenAmount", {}).get("amount", "0")
                    )
            for item in meta.get("postTokenBalances") or []:
                if item.get("mint") == SOL_USDT_MINT:
                    post[item.get("accountIndex")] = int(
                        item.get("uiTokenAmount", {}).get("amount", "0")
                    )

            # We accept a positive balance delta in the recipient token account.
            for idx, post_amount in post.items():
                delta = post_amount - pre.get(idx, 0)
                if delta >= expected_raw:
                    return Payment(signature, "sol", delta / 1_000_000)

    return None


async def find_payment(order: sqlite3.Row) -> Payment | None:
    network = order["network"]
    expected = PLANS[order["plan"]]["price"]
    created_at = parse_iso(order["created_at"]) or (utc_now() - timedelta(hours=1))

    async with aiohttp.ClientSession() as session:
        if network == "eth":
            p = await verify_evm_payment(
                session,
                ETH_RPC_URL,
                ETH_USDT_CONTRACT,
                ETH_WALLET,
                expected,
                6,
                created_at,
            )
            if p:
                p.network = "eth"
            return p

        if network == "bnb":
            p = await verify_evm_payment(
                session,
                BSC_RPC_URL,
                BSC_USDT_CONTRACT,
                BSC_WALLET,
                expected,
                18,
                created_at,
            )
            if p:
                p.network = "bnb"
            return p

        if network == "sol":
            p = await verify_solana_payment(
                session, SOL_WALLET, expected, created_at
            )
            if p:
                p.network = "sol"
            return p

    return None


# ----------------------------
# Telegram UI
# ----------------------------

def main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📊 المدارس", callback_data="schools"),
                InlineKeyboardButton(text="💎 الاشتراك", callback_data="plans"),
            ],
            [
                InlineKeyboardButton(text="📋 حالتي", callback_data="status"),
                InlineKeyboardButton(text="📖 المساعدة", callback_data="help"),
            ],
        ]
    )


def plans_kb() -> InlineKeyboardMarkup:
    rows = []
    for key, plan in PLANS.items():
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{plan['emoji']} {plan['name']} — ${plan['price']} USDT",
                    callback_data=f"sub_{key}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔙 الرئيسية", callback_data="back_main")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def schools_kb() -> InlineKeyboardMarkup:
    rows = []
    for key, school in SCHOOLS.items():
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{school['emoji']} {school['name']}",
                    callback_data=f"school_{key}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔙 الرئيسية", callback_data="back_main")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def timeframe_kb(school: str) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=tf, callback_data=f"tf_{school}_{tf}"
            )
        ]
        for tf in SCHOOLS[school]["timeframes"]
    ]
    rows.append([InlineKeyboardButton(text="🔙 المدارس", callback_data="schools")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def coins_kb(school: str, tf: str) -> InlineKeyboardMarkup:
    rows = []
    for i in range(0, len(COINS), 2):
        row = []
        for coin in COINS[i:i + 2]:
            row.append(
                InlineKeyboardButton(
                    text=coin, callback_data=f"an_{school}_{tf}_{coin}"
                )
            )
        rows.append(row)
    rows.append(
        [InlineKeyboardButton(text="🔎 عملة أخرى", callback_data=f"custom_{school}_{tf}")]
    )
    rows.append(
        [InlineKeyboardButton(text="🔙 الفترات", callback_data=f"school_{school}")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def wallet_is_configured(network: str) -> bool:
    return bool(NETWORKS[network]["wallet"])


# ----------------------------
# Bot handlers
# ----------------------------

bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML),
)
dp = Dispatcher(storage=MemoryStorage())


@dp.message(Command("start"))
async def start(message: Message):
    await db.upsert_user(message.from_user.id, message.from_user.username)
    await message.answer(
        "🤖 <b>Trading Doshka</b>\n\n"
        "تحليل مستقل لكل مدرسة تداول، واشتراكات USDT على "
        "Solana / Ethereum / BSC.\n\n"
        "اختر من القائمة:",
        reply_markup=main_kb(),
    )


@dp.callback_query(F.data == "back_main")
async def back_main(callback: CallbackQuery):
    await callback.message.edit_text(
        "🏠 <b>القائمة الرئيسية</b>", reply_markup=main_kb()
    )
    await callback.answer()


@dp.callback_query(F.data == "schools")
async def schools(callback: CallbackQuery):
    await callback.message.edit_text(
        "📊 <b>اختر مدرسة التحليل:</b>", reply_markup=schools_kb()
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("school_"))
async def school(callback: CallbackQuery):
    key = callback.data.removeprefix("school_")
    if key not in SCHOOLS:
        await callback.answer("مدرسة غير صالحة.", show_alert=True)
        return
    s = SCHOOLS[key]
    await callback.message.edit_text(
        f"{s['emoji']} <b>{s['name']}</b>\nاختر الإطار الزمني:",
        reply_markup=timeframe_kb(key),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("tf_"))
async def timeframe(callback: CallbackQuery):
    _, school_key, tf = callback.data.split("_", 2)
    if school_key not in SCHOOLS or tf not in VALID_TF:
        await callback.answer("اختيار غير صالح.", show_alert=True)
        return
    await callback.message.edit_text(
        "💰 <b>اختر العملة:</b>", reply_markup=coins_kb(school_key, tf)
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("custom_"))
async def custom_currency(callback: CallbackQuery, state: FSMContext):
    _, school_key, tf = callback.data.split("_", 2)
    await state.update_data(school=school_key, timeframe=tf)
    await state.set_state(States.custom)
    await callback.message.edit_text(
        "🔎 أرسل رمز العملة فقط، مثال: <code>BTC</code>"
    )
    await callback.answer()


@dp.message(States.custom)
async def custom_currency_message(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    symbol = normalize_symbol(message.text or "")
    if not symbol:
        await message.answer("❌ رمز العملة غير صالح.", reply_markup=main_kb())
        return
    await do_analysis(
        message,
        symbol,
        data.get("school", "classic"),
        data.get("timeframe", "1h"),
    )


async def do_analysis(
    target: Message,
    symbol: str,
    school_key: str,
    timeframe: str,
):
    if school_key not in ANALYZERS or timeframe not in VALID_TF:
        await target.answer("❌ إعداد التحليل غير صالح.")
        return

    if not await db.is_active(target.chat.id):
        await target.answer(
            "🔒 <b>الاشتراك غير نشط.</b>\n\n"
            "اشترك أولًا من زر «💎 الاشتراك».",
            reply_markup=main_kb(),
        )
        return

    status_message = await target.answer(
        f"⏳ جاري جلب بيانات <b>{symbol}/USDT</b>..."
    )
    candles = await get_klines(symbol, timeframe)

    if len(candles) < 80:
        await status_message.edit_text(
            "❌ لم تصل بيانات كافية من مزود السوق.\n"
            "جرّب عملة أخرى أو بعد قليل."
        )
        return

    try:
        signal = ANALYZERS[school_key](candles, symbol)
        chart = render_chart(
            candles[-120:],
            signal,
            symbol,
            SCHOOLS[school_key]["name"],
        )
        await status_message.delete()
        await target.answer_photo(
            BufferedInputFile(
                chart.read(),
                filename=f"{symbol}_{school_key}_{timeframe}.png",
            ),
            caption=signal["analysis"],
            reply_markup=main_kb(),
        )
    except Exception as exc:
        log.exception("Analysis error")
        await status_message.edit_text(
            "❌ حدث خطأ داخلي أثناء التحليل. حاول مرة أخرى."
        )


@dp.callback_query(F.data.startswith("an_"))
async def analyze(callback: CallbackQuery):
    _, school_key, tf, symbol = callback.data.split("_", 3)
    await callback.answer("⏳ جاري التحليل...")
    await do_analysis(callback.message, symbol, school_key, tf)


@dp.callback_query(F.data == "plans")
async def plans(callback: CallbackQuery):
    await callback.message.edit_text(
        "<b>💎 الاشتراكات — USDT فقط</b>\n\nاختر الباقة:",
        reply_markup=plans_kb(),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("sub_"))
async def subscription_plan(callback: CallbackQuery):
    plan = callback.data.removeprefix("sub_")
    if plan not in PLANS:
        await callback.answer("الباقة غير صالحة.", show_alert=True)
        return

    rows = []
    for network_key in ("sol", "eth", "bnb"):
        network = NETWORKS[network_key]
        available = "✅" if wallet_is_configured(network_key) else "⚠️"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{available} USDT — {network['name']}",
                    callback_data=f"net_{plan}_{network_key}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔙 الباقات", callback_data="plans")])

    await callback.message.edit_text(
        f"💳 <b>{PLANS[plan]['name']}</b>\n"
        f"💵 ${PLANS[plan]['price']:.2f} USDT\n\n"
        "اختر الشبكة:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("net_"))
async def choose_network(callback: CallbackQuery):
    _, plan, network = callback.data.split("_", 2)
    if plan not in PLANS or network not in NETWORKS:
        await callback.answer("اختيار غير صالح.", show_alert=True)
        return

    wallet = NETWORKS[network]["wallet"]
    if not wallet:
        await callback.answer(
            "هذه الشبكة غير مهيأة بعد في Railway.",
            show_alert=True,
        )
        return

    await db.upsert_user(callback.from_user.id, callback.from_user.username)
    order_id = await db.create_order(callback.from_user.id, plan, network)

    await callback.message.edit_text(
        f"💳 <b>طلب الدفع #{order_id}</b>\n\n"
        f"💵 المبلغ: <b>${PLANS[plan]['price']:.2f} USDT</b>\n"
        f"🌐 الشبكة: <b>{NETWORKS[network]['name']}</b>\n\n"
        f"📮 أرسل USDT إلى:\n<code>{wallet}</code>\n\n"
        "⚠️ تأكد أن الشبكة هي نفسها المحددة أعلاه.\n"
        "🔎 لا ترسل TX Hash؛ النظام يبحث تلقائيًا عن التحويل.\n\n"
        "بعد التحويل اضغط «🔄 فحص الآن».",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="🔄 فحص الآن", callback_data="check")],
                [InlineKeyboardButton(text="🔙 الباقات", callback_data="plans")],
            ]
        ),
    )
    await callback.answer()


@dp.callback_query(F.data == "check")
async def check_payment(callback: CallbackQuery):
    order = await db.pending_order(callback.from_user.id)
    if not order:
        await callback.answer("لا يوجد طلب دفع معلّق.", show_alert=True)
        return

    await callback.answer("🔎 جاري الفحص...")
    if not wallet_is_configured(order["network"]):
        await callback.message.answer(
            "❌ محفظة هذه الشبكة غير مهيأة في Railway."
        )
        return

    payment = await find_payment(order)
    if not payment:
        await callback.message.answer(
            "❌ لم يتم العثور على دفعة USDT مكتملة بالمبلغ المطلوب حتى الآن.\n\n"
            f"المطلوب: <b>${PLANS[order['plan']]['price']:.2f} USDT</b>\n"
            f"الشبكة: <b>{NETWORKS[order['network']]['name']}</b>\n\n"
            "تأكد من المبلغ والشبكة وانتظر تأكيد المعاملة ثم أعد الفحص."
        )
        return

    claimed = await db.claim_transaction(
        payment.tx_id,
        callback.from_user.id,
        order["plan"],
        order["network"],
        payment.amount,
    )
    if not claimed:
        await callback.message.answer("⚠️ هذه المعاملة مستخدمة مسبقًا.")
        return

    expires = await db.activate(callback.from_user.id, order["plan"])
    await callback.message.answer(
        "🎉 <b>تم تفعيل الاشتراك بنجاح!</b>\n\n"
        f"📦 {PLANS[order['plan']]['name']}\n"
        f"💵 {payment.amount:.2f} USDT\n"
        f"🌐 {NETWORKS[order['network']]['name']}\n"
        f"📅 حتى: {expires.strftime('%Y-%m-%d %H:%M UTC')}",
        reply_markup=main_kb(),
    )


@dp.callback_query(F.data == "status")
async def subscription_status(callback: CallbackQuery):
    row = await db.status(callback.from_user.id)
    if not row or not row["is_active"]:
        text = "❌ <b>لا يوجد اشتراك نشط.</b>"
    else:
        plan_name = PLANS.get(row["plan"], {}).get("name", row["plan"])
        text = (
            "✅ <b>اشتراك نشط</b>\n\n"
            f"📦 {plan_name}\n"
            f"📅 حتى: {row['expire_date']}"
        )

    await callback.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="🔙 الرئيسية", callback_data="back_main")]
            ]
        ),
    )
    await callback.answer()


@dp.callback_query(F.data == "help")
async def help_handler(callback: CallbackQuery):
    await callback.message.edit_text(
        "<b>📖 المدارس</b>\n\n"
        "📊 وايكوف — السعر والحجم وبصمة التجميع/التوزيع.\n"
        "🌊 إليوت — بنية القمم والقيعان.\n"
        "🦋 هارمونيك — نسب فيبوناتشي احتمالية.\n"
        "📈 كلاسيكي — EMA/RSI/الحجم.\n"
        "🐋 الحيتان — نشاط حجمي غير اعتيادي.\n"
        "💧 السيولة — حركة السعر والحجم.\n\n"
        "💵 الدفع: USDT على Solana / Ethereum / BSC.\n"
        "⚠️ التحليل لأغراض معلوماتية وليس ضمانًا للربح.",
        reply_markup=main_kb(),
    )
    await callback.answer()


# ----------------------------
# Background tasks
# ----------------------------

async def process_pending_payments() -> None:
    orders = await db.pending_orders()
    for order in orders:
        try:
            payment = await find_payment(order)
            if not payment:
                continue

            claimed = await db.claim_transaction(
                payment.tx_id,
                order["user_id"],
                order["plan"],
                order["network"],
                payment.amount,
            )
            if not claimed:
                continue

            expires = await db.activate(order["user_id"], order["plan"])
            await bot.send_message(
                order["user_id"],
                "🎉 <b>تم تفعيل الاشتراك تلقائيًا!</b>\\n\\n"
                f"📦 {PLANS[order['plan']]['name']}\\n"
                f"💵 {payment.amount:.2f} USDT\\n"
                f"🌐 {NETWORKS[order['network']]['name']}\\n"
                f"📅 حتى: {expires.strftime('%Y-%m-%d %H:%M UTC')}",
                reply_markup=main_kb(),
            )
        except Exception:
            log.exception("Payment monitor error for order %s", order["id"])


async def payment_monitor_loop():
    while True:
        try:
            await process_pending_payments()
        except Exception:
            log.exception("Payment monitor cycle failed")
        await asyncio.sleep(PAYMENT_SCAN_SECONDS)


async def maintenance_loop():
    while True:
        try:
            await db.deactivate_expired()
        except Exception:
            log.exception("Maintenance error")
        await asyncio.sleep(300)


async def main():
    await db.init()

    if not SOL_WALLET:
        log.warning("SOL_WALLET is empty")
    if not ETH_WALLET:
        log.warning("ETH_WALLET is empty")
    if not BSC_WALLET:
        log.warning("BSC_WALLET is empty")

    maintenance = asyncio.create_task(maintenance_loop())
    payment_monitor = asyncio.create_task(payment_monitor_loop())
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        log.info("Bot started")
        await dp.start_polling(bot)
    finally:
        maintenance.cancel()
        payment_monitor.cancel()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
